# Social Media Calendar 2026
YouTube & Instagram planning and analytics dashboard.

## Features
- 12-month calendar view with week-level scheduling
- YouTube & Instagram post planning (Long-form, Reels, Carousels, Stories, etc.)
- Engagement data logging (views, likes, comments, shares, watch time)
- Analytics dashboard: reach charts, engagement split, top posts, content type performance
- Data persists in localStorage — your posts survive browser refreshes

---

## Run locally

**Requirements:** Node.js 18+ (download from https://nodejs.org)

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Open http://localhost:5173 in your browser
```

---

## Deploy to Vercel (free, ~2 minutes)

### Option A — Vercel CLI (fastest)
```bash
npm install -g vercel
vercel
```
Follow the prompts. Your app will be live at a `.vercel.app` URL.

### Option B — GitHub + Vercel (recommended for ongoing use)
1. Push this folder to a GitHub repository
2. Go to https://vercel.com → New Project → Import your repo
3. Leave all settings as default → click **Deploy**
4. Done — every push to main auto-deploys

### Option C — Netlify
```bash
npm run build
# Then drag the `dist/` folder to https://app.netlify.com/drop
```

---

## Deploy to Netlify (drag & drop)
```bash
npm run build
```
Go to https://app.netlify.com/drop and drag the generated `dist/` folder. Done.

---

## Customise
- Edit `src/App.jsx` to add new fields, platforms, or chart types
- Edit `src/index.css` for colors and fonts
- Posts are stored in `localStorage` under the key `smcal_posts_2026`
