import { useState, useEffect, useRef } from 'react'
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  ArcElement, Tooltip, Legend, Title
} from 'chart.js'
import { Bar, Doughnut } from 'react-chartjs-2'

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend, Title)

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']
const SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

const SAMPLE_POSTS = [
  { id:1, platform:'YouTube', type:'Long-form video', date:'2026-01-15', title:'2026 Goals & Content Strategy', status:'Published', caption:'', engagement:{ views:4200, likes:310, comments:45, shares:80, watch:1800 }},
  { id:2, platform:'Instagram', type:'Carousel', date:'2026-01-20', title:'5 Tips for Instagram Growth', status:'Published', caption:'', engagement:{ views:3100, likes:280, comments:32, shares:95, watch:0 }},
  { id:3, platform:'YouTube', type:'Short / Reel', date:'2026-02-05', title:'Quick Tutorial: Editing Tricks', status:'Published', caption:'', engagement:{ views:8900, likes:710, comments:88, shares:140, watch:0 }},
  { id:4, platform:'Instagram', type:'Story', date:'2026-02-14', title:"Valentine's Day BTS", status:'Published', caption:'', engagement:{ views:1200, likes:98, comments:12, shares:20, watch:0 }},
  { id:5, platform:'YouTube', type:'Long-form video', date:'2026-03-10', title:'Full Brand Audit: Case Study', status:'Planned', caption:'', engagement:null },
  { id:6, platform:'Instagram', type:'Static post', date:'2026-03-22', title:'Spring Collection Drop', status:'Draft', caption:'', engagement:null },
]

function useLocalStorage(key, initial) {
  const [val, setVal] = useState(() => {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : initial }
    catch { return initial }
  })
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(val)) } catch {} }, [key, val])
  return [val, setVal]
}

const STATUS_COLORS = { Planned: '#378ADD', Published: '#639922', Draft: '#888780' }

const s = {
  app: { maxWidth: 900, margin: '0 auto', padding: '0 24px 60px' },
  header: { display:'flex', alignItems:'center', justifyContent:'space-between', padding:'28px 0 20px' },
  logoWrap: { display:'flex', alignItems:'center', gap:10 },
  logoIcon: { width:36, height:36, background:'#378ADD', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:18 },
  logoTitle: { fontSize:18, fontWeight:600, color:'var(--text)' },
  logoSub: { fontSize:12, color:'var(--text2)', marginTop:1 },
  headerRight: { display:'flex', gap:8 },
  tabs: { display:'flex', gap:2, borderBottom:'0.5px solid var(--border)', marginBottom:24 },
  tab: (active) => ({ padding:'9px 18px', fontSize:13, fontWeight: active?600:400, cursor:'pointer', border:'none', background:'none', color: active?'var(--text)':'var(--text2)', borderBottom: active?'2px solid #378ADD':'2px solid transparent', marginBottom:-0.5, transition:'all .15s', display:'flex', alignItems:'center', gap:6 }),
  monthGrid: { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(180px, 1fr))', gap:10, marginBottom:24 },
  monthCard: (selected) => ({ background:'var(--surface)', border: selected?'1.5px solid #378ADD':'0.5px solid var(--border)', borderRadius:12, padding:'12px 14px', cursor:'pointer', transition:'border-color .15s' }),
  monthName: { fontSize:13, fontWeight:600, color:'var(--text)', marginBottom:5 },
  monthMeta: { fontSize:11, color:'var(--text2)' },
  pill: (type) => ({ display:'inline-block', fontSize:10, fontWeight:600, padding:'2px 7px', borderRadius:99, marginRight:4, marginTop:5, background: type==='yt'?'var(--red-bg)':'var(--purple-bg)', color: type==='yt'?'var(--red-text)':'var(--purple-text)' }),
  sectionHead: { display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 },
  sectionLabel: { fontSize:11, fontWeight:600, color:'var(--text2)', textTransform:'uppercase', letterSpacing:'.06em' },
  table: { width:'100%', borderCollapse:'collapse', fontSize:13, marginBottom:24 },
  th: { background:'var(--surface2)', color:'var(--text2)', fontWeight:500, fontSize:11, textAlign:'left', padding:'8px 12px', borderBottom:'0.5px solid var(--border)' },
  td: { padding:'10px 12px', borderBottom:'0.5px solid var(--border)', color:'var(--text)', verticalAlign:'top' },
  badge: (type) => ({ fontSize:10, fontWeight:600, padding:'2px 8px', borderRadius:99, background: type==='YouTube'?'var(--red-bg)':'var(--purple-bg)', color: type==='YouTube'?'var(--red-text)':'var(--purple-text)', whiteSpace:'nowrap' }),
  addBtn: { display:'flex', alignItems:'center', gap:6, fontSize:13, padding:'7px 14px', border:'0.5px solid var(--border2)', borderRadius:8, background:'none', color:'var(--text)', cursor:'pointer', marginBottom:16 },
  btnPrimary: { padding:'8px 20px', background:'#378ADD', color:'#fff', border:'none', borderRadius:8, fontSize:13, cursor:'pointer', fontWeight:600 },
  btnGhost: { padding:'7px 14px', background:'none', border:'0.5px solid var(--border2)', borderRadius:8, fontSize:13, cursor:'pointer', color:'var(--text2)', display:'flex', alignItems:'center', gap:5 },
  formRow: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:10 },
  formRow3: { display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10, marginBottom:10 },
  formGroup: { display:'flex', flexDirection:'column', gap:4 },
  label: { fontSize:11, color:'var(--text2)', fontWeight:600 },
  input: { fontSize:13, padding:'8px 10px', borderRadius:8, border:'0.5px solid var(--border2)', background:'var(--surface)', color:'var(--text)', outline:'none' },
  metricGrid: { display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:10, marginBottom:24 },
  metricCard: { background:'var(--surface2)', borderRadius:8, padding:'14px 16px' },
  metricLabel: { fontSize:11, color:'var(--text2)', marginBottom:4 },
  metricVal: { fontSize:24, fontWeight:600, color:'var(--text)' },
  metricSub: { fontSize:11, color:'var(--text3)', marginTop:2 },
  dashGrid: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:16 },
  chartCard: { background:'var(--surface)', border:'0.5px solid var(--border)', borderRadius:12, padding:'14px 16px' },
  chartTitle: { fontSize:12, fontWeight:600, color:'var(--text2)', marginBottom:10, textTransform:'uppercase', letterSpacing:'.05em' },
  engForm: { background:'var(--surface2)', borderRadius:12, padding:'16px', marginBottom:24 },
  postItem: { background:'var(--surface)', border:'0.5px solid var(--border)', borderRadius:8, padding:'10px 14px', display:'flex', alignItems:'center', gap:12, marginBottom:8 },
  delBtn: { fontSize:16, color:'var(--text3)', background:'none', border:'none', cursor:'pointer', padding:'2px 6px', borderRadius:4, lineHeight:1 },
  overlay: { position:'fixed', inset:0, background:'rgba(0,0,0,0.35)', zIndex:100, display:'flex', alignItems:'center', justifyContent:'center', padding:24 },
  modal: { background:'var(--surface)', border:'0.5px solid var(--border)', borderRadius:16, padding:24, width:'100%', maxWidth:520 },
  modalTitle: { fontSize:16, fontWeight:600, marginBottom:16, color:'var(--text)' },
  statusDot: (status) => ({ width:7, height:7, borderRadius:'50%', background: STATUS_COLORS[status]||'#888', display:'inline-block', marginRight:5 }),
}

export default function App() {
  const [posts, setPosts] = useLocalStorage('smcal_posts_2026', SAMPLE_POSTS)
  const [nextId, setNextId] = useLocalStorage('smcal_nextid', 7)
  const [tab, setTab] = useState('calendar')
  const [selectedMonth, setSelectedMonth] = useState(null)
  const [showModal, setShowModal] = useState(false)
  const [postFilter, setPostFilter] = useState('all')
  const [form, setForm] = useState({ platform:'YouTube', type:'Long-form video', date:'', title:'', caption:'', status:'Planned' })
  const [engForm, setEngForm] = useState({ postId:'', views:'', likes:'', comments:'', shares:'', watch:'' })
  const [saved, setSaved] = useState(false)

  const published = posts.filter(p => p.engagement)
  const totalViews = published.reduce((a,p) => a + p.engagement.views, 0)
  const totalLikes = published.reduce((a,p) => a + p.engagement.likes, 0)
  const totalComments = published.reduce((a,p) => a + p.engagement.comments, 0)
  const totalShares = published.reduce((a,p) => a + p.engagement.shares, 0)
  const engRate = totalViews > 0 ? ((totalLikes + totalComments + totalShares) / totalViews * 100) : 0

  function fmt(n) { return n >= 1000 ? (n/1000).toFixed(1)+'k' : n }

  function addPost() {
    if (!form.title.trim()) return
    const newPost = { ...form, id: nextId, engagement: null }
    setPosts(p => [...p, newPost])
    setNextId(id => id + 1)
    setShowModal(false)
    setForm({ platform:'YouTube', type:'Long-form video', date:'', title:'', caption:'', status:'Planned' })
  }

  function deletePost(id) {
    setPosts(p => p.filter(x => x.id !== id))
  }

  function logEngagement() {
    if (!engForm.postId) return
    setPosts(p => p.map(post => post.id === parseInt(engForm.postId)
      ? { ...post, status:'Published', engagement:{ views:parseInt(engForm.views)||0, likes:parseInt(engForm.likes)||0, comments:parseInt(engForm.comments)||0, shares:parseInt(engForm.shares)||0, watch:parseInt(engForm.watch)||0 }}
      : post
    ))
    setEngForm({ postId:'', views:'', likes:'', comments:'', shares:'', watch:'' })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  function openMonth(m) {
    setSelectedMonth(m)
  }

  const monthPosts = selectedMonth !== null ? posts.filter(p => new Date(p.date).getMonth() === selectedMonth) : []

  const filteredPosts = postFilter === 'all' ? posts : posts.filter(p => p.platform === postFilter)

  const monthlyYT = Array(12).fill(0)
  const monthlyIG = Array(12).fill(0)
  published.forEach(p => {
    const m = new Date(p.date).getMonth()
    if (p.platform === 'YouTube') monthlyYT[m] += p.engagement.views
    else monthlyIG[m] += p.engagement.views
  })

  const ytEng = published.filter(p => p.platform==='YouTube').reduce((a,p) => a + p.engagement.likes + p.engagement.comments + p.engagement.shares, 0)
  const igEng = published.filter(p => p.platform==='Instagram').reduce((a,p) => a + p.engagement.likes + p.engagement.comments + p.engagement.shares, 0)

  const typeMap = {}
  published.forEach(p => {
    if (!typeMap[p.type]) typeMap[p.type] = { views:0, eng:0 }
    typeMap[p.type].views += p.engagement.views
    typeMap[p.type].eng += p.engagement.likes + p.engagement.comments + p.engagement.shares
  })
  const typeLabels = Object.keys(typeMap)
  const typeRates = typeLabels.map(t => typeMap[t].views > 0 ? parseFloat((typeMap[t].eng / typeMap[t].views * 100).toFixed(1)) : 0)

  const topPosts = [...published].sort((a,b) =>
    (b.engagement.likes+b.engagement.comments+b.engagement.shares) -
    (a.engagement.likes+a.engagement.comments+a.engagement.shares)
  ).slice(0, 5)
  const maxEng = topPosts.length ? topPosts[0].engagement.likes + topPosts[0].engagement.comments + topPosts[0].engagement.shares : 1

  const chartOpts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid:{ display:false }, ticks:{ font:{ size:10, family:'DM Sans' }, color:'#888' }},
      y: { grid:{ color:'rgba(128,128,128,0.1)' }, ticks:{ font:{ size:10, family:'DM Sans' }, color:'#888', callback: v => v >= 1000 ? (v/1000)+'k' : v }}
    }
  }

  return (
    <div style={s.app}>
      {/* Header */}
      <div style={s.header}>
        <div style={s.logoWrap}>
          <div style={s.logoIcon}><i className="ti ti-calendar" /></div>
          <div>
            <div style={s.logoTitle}>Social Calendar</div>
            <div style={s.logoSub}>YouTube & Instagram · 2026</div>
          </div>
        </div>
        <div style={s.headerRight}>
          <div style={{ fontSize:12, color:'var(--text3)', display:'flex', alignItems:'center', gap:5 }}>
            <i className="ti ti-database" style={{ fontSize:13 }} />
            {posts.length} posts · {published.length} with data
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={s.tabs}>
        {[['calendar','ti-calendar','Calendar'],['posts','ti-list','Posts'],['analytics','ti-chart-bar','Analytics']].map(([id,icon,label]) => (
          <button key={id} style={s.tab(tab===id)} onClick={() => setTab(id)}>
            <i className={`ti ${icon}`} style={{ fontSize:14 }} />{label}
          </button>
        ))}
      </div>

      {/* CALENDAR TAB */}
      {tab === 'calendar' && (
        <div>
          {selectedMonth === null ? (
            <div style={s.monthGrid}>
              {MONTHS.map((name, i) => {
                const mPosts = posts.filter(p => new Date(p.date).getMonth() === i)
                const yt = mPosts.filter(p => p.platform==='YouTube').length
                const ig = mPosts.filter(p => p.platform==='Instagram').length
                return (
                  <div key={i} style={s.monthCard(false)} onClick={() => openMonth(i)}>
                    <div style={s.monthName}>{name}</div>
                    <div style={s.monthMeta}>{mPosts.length} post{mPosts.length!==1?'s':''}</div>
                    <div style={{ marginTop:6 }}>
                      {yt > 0 && <span style={s.pill('yt')}>YT {yt}</span>}
                      {ig > 0 && <span style={s.pill('ig')}>IG {ig}</span>}
                      {!yt && !ig && <span style={{ fontSize:10, color:'var(--text3)' }}>Nothing yet</span>}
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div>
              <div style={s.sectionHead}>
                <span style={{ fontSize:16, fontWeight:600 }}>{MONTHS[selectedMonth]} 2026</span>
                <button style={s.btnGhost} onClick={() => setSelectedMonth(null)}>
                  <i className="ti ti-arrow-left" style={{ fontSize:13 }} />Back to months
                </button>
              </div>
              <button style={s.addBtn} onClick={() => { setForm(f => ({...f, date:`2026-${String(selectedMonth+1).padStart(2,'0')}-01`})); setShowModal(true) }}>
                <i className="ti ti-plus" style={{ fontSize:14 }} />Add post for {MONTHS[selectedMonth]}
              </button>
              <table style={s.table}>
                <thead>
                  <tr>
                    {['Week','Date','Platform','Type','Title / Topic','Status',''].map(h => (
                      <th key={h} style={s.th}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {monthPosts.length === 0 ? (
                    <tr><td colSpan={7} style={{ ...s.td, textAlign:'center', color:'var(--text2)', padding:'2rem' }}>No posts scheduled. Add one above.</td></tr>
                  ) : [...monthPosts].sort((a,b) => new Date(a.date)-new Date(b.date)).map(p => {
                    const d = new Date(p.date)
                    const weekNum = Math.ceil(d.getDate() / 7)
                    return (
                      <tr key={p.id} style={{ background:'transparent' }}>
                        <td style={s.td}><span style={{ fontSize:11, color:'var(--text3)' }}>W{weekNum}</span></td>
                        <td style={s.td}>{d.getDate()} {SHORT[d.getMonth()]}</td>
                        <td style={s.td}><span style={s.badge(p.platform)}>{p.platform==='YouTube'?'YT':'IG'}</span></td>
                        <td style={{ ...s.td, fontSize:12, color:'var(--text2)' }}>{p.type}</td>
                        <td style={{ ...s.td, maxWidth:200, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.title}</td>
                        <td style={s.td}><span style={s.statusDot(p.status)} />{p.status}</td>
                        <td style={s.td}><button style={s.delBtn} onClick={() => deletePost(p.id)} aria-label="Delete">×</button></td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* POSTS TAB */}
      {tab === 'posts' && (
        <div>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
            <div style={{ display:'flex', gap:8 }}>
              {[['all','All'],['YouTube','YouTube'],['Instagram','Instagram']].map(([v,l]) => (
                <button key={v} style={{ ...s.btnGhost, fontWeight: postFilter===v?600:400, borderColor: postFilter===v?'var(--border2)':'var(--border)', fontSize:12, padding:'5px 12px' }} onClick={() => setPostFilter(v)}>{l}</button>
              ))}
            </div>
            <button style={s.addBtn} onClick={() => setShowModal(true)}>
              <i className="ti ti-plus" style={{ fontSize:14 }} />Add post
            </button>
          </div>
          {filteredPosts.length === 0 ? (
            <div style={{ textAlign:'center', padding:'3rem', color:'var(--text2)', fontSize:13 }}>No posts yet.</div>
          ) : [...filteredPosts].sort((a,b) => new Date(a.date)-new Date(b.date)).map(p => (
            <div key={p.id} style={s.postItem}>
              <span style={s.badge(p.platform)}>{p.platform==='YouTube'?'YT':'IG'}</span>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:13, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.title}</div>
                <div style={{ fontSize:11, color:'var(--text2)', marginTop:2 }}>
                  {new Date(p.date).toLocaleDateString('en-GB',{day:'numeric',month:'short'})} · {p.type} · <span style={s.statusDot(p.status)} />{p.status}
                </div>
              </div>
              {p.engagement ? (
                <div style={{ display:'flex', gap:16, textAlign:'center' }}>
                  {[['reach',fmt(p.engagement.views)],['likes',p.engagement.likes],['comments',p.engagement.comments]].map(([lbl,val]) => (
                    <div key={lbl}>
                      <div style={{ fontSize:15, fontWeight:600 }}>{val}</div>
                      <div style={{ fontSize:10, color:'var(--text3)' }}>{lbl}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <span style={{ fontSize:11, color:'var(--text3)' }}>No data</span>
              )}
              <button style={s.delBtn} onClick={() => deletePost(p.id)}>×</button>
            </div>
          ))}
        </div>
      )}

      {/* ANALYTICS TAB */}
      {tab === 'analytics' && (
        <div>
          {/* Summary metrics */}
          <div style={s.metricGrid}>
            {[
              ['Total reach', fmt(totalViews), `${published.length} published posts`],
              ['Total likes', fmt(totalLikes), 'all platforms'],
              ['Comments', totalComments, 'total interactions'],
              ['Avg eng. rate', engRate.toFixed(1)+'%', 'likes+comments+shares÷reach'],
            ].map(([label, val, sub]) => (
              <div key={label} style={s.metricCard}>
                <div style={s.metricLabel}>{label}</div>
                <div style={s.metricVal}>{val}</div>
                <div style={s.metricSub}>{sub}</div>
              </div>
            ))}
          </div>

          {/* Log engagement form */}
          <div style={s.engForm}>
            <div style={{ fontSize:13, fontWeight:600, marginBottom:12, display:'flex', alignItems:'center', gap:6 }}>
              <i className="ti ti-pencil" style={{ fontSize:15 }} />Log engagement data
            </div>
            <div style={s.formRow3}>
              <div style={s.formGroup}>
                <label style={s.label}>Post</label>
                <select style={s.input} value={engForm.postId} onChange={e => setEngForm(f => ({...f, postId:e.target.value}))}>
                  <option value="">— select a post —</option>
                  {posts.map(p => <option key={p.id} value={p.id}>[{p.platform==='YouTube'?'YT':'IG'}] {p.title.slice(0,38)}{p.title.length>38?'…':''}</option>)}
                </select>
              </div>
              <div style={s.formGroup}>
                <label style={s.label}>Views / Reach</label>
                <input style={s.input} type="number" placeholder="e.g. 5400" value={engForm.views} onChange={e => setEngForm(f => ({...f, views:e.target.value}))} />
              </div>
              <div style={s.formGroup}>
                <label style={s.label}>Likes</label>
                <input style={s.input} type="number" placeholder="e.g. 320" value={engForm.likes} onChange={e => setEngForm(f => ({...f, likes:e.target.value}))} />
              </div>
            </div>
            <div style={s.formRow3}>
              <div style={s.formGroup}>
                <label style={s.label}>Comments</label>
                <input style={s.input} type="number" placeholder="e.g. 48" value={engForm.comments} onChange={e => setEngForm(f => ({...f, comments:e.target.value}))} />
              </div>
              <div style={s.formGroup}>
                <label style={s.label}>Shares / Saves</label>
                <input style={s.input} type="number" placeholder="e.g. 90" value={engForm.shares} onChange={e => setEngForm(f => ({...f, shares:e.target.value}))} />
              </div>
              <div style={s.formGroup}>
                <label style={s.label}>Watch time (min) — YT only</label>
                <input style={s.input} type="number" placeholder="e.g. 2200" value={engForm.watch} onChange={e => setEngForm(f => ({...f, watch:e.target.value}))} />
              </div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <button style={s.btnPrimary} onClick={logEngagement}>Save engagement</button>
              {saved && <span style={{ fontSize:12, color:'var(--green)', display:'flex', alignItems:'center', gap:4 }}><i className="ti ti-check" />Saved!</span>}
            </div>
          </div>

          {/* Charts row */}
          <div style={s.dashGrid}>
            <div style={s.chartCard}>
              <div style={s.chartTitle}>Monthly reach — YT vs IG</div>
              <div style={{ display:'flex', gap:12, marginBottom:8, flexWrap:'wrap' }}>
                {[['#D85A30','YouTube'],['#7F77DD','Instagram']].map(([c,l]) => (
                  <span key={l} style={{ fontSize:11, color:'var(--text2)', display:'flex', alignItems:'center', gap:4 }}>
                    <span style={{ width:10, height:10, borderRadius:2, background:c, display:'inline-block' }} />{l}
                  </span>
                ))}
              </div>
              <div style={{ position:'relative', height:160 }}>
                <Bar data={{ labels:SHORT, datasets:[{ label:'YouTube', data:monthlyYT, backgroundColor:'#D85A30', borderWidth:0 },{ label:'Instagram', data:monthlyIG, backgroundColor:'#7F77DD', borderWidth:0 }]}} options={chartOpts} />
              </div>
            </div>
            <div style={s.chartCard}>
              <div style={s.chartTitle}>Engagement split</div>
              <div style={{ display:'flex', gap:12, marginBottom:8 }}>
                {[['#D85A30','YouTube',ytEng],['#7F77DD','Instagram',igEng]].map(([c,l,v]) => (
                  <span key={l} style={{ fontSize:11, color:'var(--text2)', display:'flex', alignItems:'center', gap:4 }}>
                    <span style={{ width:10, height:10, borderRadius:2, background:c, display:'inline-block' }} />{l} {v}
                  </span>
                ))}
              </div>
              <div style={{ position:'relative', height:160 }}>
                <Doughnut data={{ labels:['YouTube','Instagram'], datasets:[{ data:[ytEng||1, igEng||1], backgroundColor:['#D85A30','#7F77DD'], borderWidth:0, hoverOffset:4 }]}} options={{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false }}, cutout:'65%' }} />
              </div>
            </div>
          </div>

          {/* Top posts */}
          <div style={{ ...s.chartCard, marginBottom:12 }}>
            <div style={s.chartTitle}>Top posts by engagement</div>
            {topPosts.length === 0 ? (
              <div style={{ fontSize:13, color:'var(--text2)', padding:'1rem 0', textAlign:'center' }}>Log engagement data to see top posts.</div>
            ) : topPosts.map(p => {
              const total = p.engagement.likes + p.engagement.comments + p.engagement.shares
              const pct = Math.round(total / maxEng * 100)
              return (
                <div key={p.id} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8, fontSize:11 }}>
                  <span style={{ ...s.badge(p.platform), minWidth:28, textAlign:'center' }}>{p.platform==='YouTube'?'YT':'IG'}</span>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ color:'var(--text2)', marginBottom:3, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.title}</div>
                    <div style={{ height:8, background:'var(--surface2)', borderRadius:99, overflow:'hidden' }}>
                      <div style={{ width:`${pct}%`, height:'100%', background: p.platform==='YouTube'?'#D85A30':'#7F77DD', borderRadius:99, transition:'width .4s ease' }} />
                    </div>
                  </div>
                  <span style={{ color:'var(--text2)', minWidth:32, textAlign:'right' }}>{total}</span>
                </div>
              )
            })}
          </div>

          {/* Content type chart */}
          <div style={s.chartCard}>
            <div style={s.chartTitle}>Content type performance (eng. rate %)</div>
            <div style={{ position:'relative', height:140 }}>
              <Bar data={{ labels: typeLabels.length ? typeLabels : ['No data'], datasets:[{ label:'Eng. rate %', data: typeRates.length ? typeRates : [0], backgroundColor:'#1D9E75', borderWidth:0, borderRadius:4 }]}} options={{ ...chartOpts, scales:{ ...chartOpts.scales, y:{ ...chartOpts.scales.y, ticks:{ ...chartOpts.scales.y.ticks, callback: v => v+'%' }}}}} />
            </div>
          </div>
        </div>
      )}

      {/* Add Post Modal */}
      {showModal && (
        <div style={s.overlay} onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div style={s.modal}>
            <div style={s.modalTitle}>New post</div>
            <div style={s.formRow}>
              <div style={s.formGroup}>
                <label style={s.label}>Platform</label>
                <select style={s.input} value={form.platform} onChange={e => setForm(f => ({...f, platform:e.target.value}))}>
                  <option>YouTube</option>
                  <option>Instagram</option>
                </select>
              </div>
              <div style={s.formGroup}>
                <label style={s.label}>Content type</label>
                <select style={s.input} value={form.type} onChange={e => setForm(f => ({...f, type:e.target.value}))}>
                  {['Long-form video','Short / Reel','Carousel','Story','Static post','Live'].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div style={s.formRow}>
              <div style={s.formGroup}>
                <label style={s.label}>Date</label>
                <input style={s.input} type="date" value={form.date} onChange={e => setForm(f => ({...f, date:e.target.value}))} />
              </div>
              <div style={s.formGroup}>
                <label style={s.label}>Status</label>
                <select style={s.input} value={form.status} onChange={e => setForm(f => ({...f, status:e.target.value}))}>
                  {['Planned','Draft','Published'].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div style={{ ...s.formGroup, marginBottom:10 }}>
              <label style={s.label}>Title / Topic</label>
              <input style={s.input} type="text" placeholder="e.g. How I grew 10k subscribers in 60 days" value={form.title} onChange={e => setForm(f => ({...f, title:e.target.value}))} />
            </div>
            <div style={{ ...s.formGroup, marginBottom:16 }}>
              <label style={s.label}>Caption / Description (optional)</label>
              <textarea style={{ ...s.input, resize:'vertical', minHeight:60 }} placeholder="Post caption or video description..." value={form.caption} onChange={e => setForm(f => ({...f, caption:e.target.value}))} />
            </div>
            <div style={{ display:'flex', gap:10 }}>
              <button style={s.btnPrimary} onClick={addPost}>Add post</button>
              <button style={s.btnGhost} onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
